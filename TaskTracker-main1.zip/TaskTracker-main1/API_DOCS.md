# API Documentation

Base URL:

http://localhost/TaskTracker-main1/php-rest-api/index.php


## Task Endpoints

### GET /index.php

Returns all tasks and categories.

Request body:

None.

Success response — 200 OK:

```json
{
  "tasks": [
    {
      "id": 1,
      "name": "Take out the trash",
      "status": "Not Started",
      "dueDate": "2023-10-10",
      "estimatedTime": 60,
      "timeSpent": 0,
      "description": "Take out the trash to the curb for pickup.",
      "categoryId": 1,
      "completedOn": ""
    },
    {
      "id": 2,
      "name": "Finish homework",
      "status": "In Progress",
      "dueDate": "2023-10-12",
      "estimatedTime": 120,
      "timeSpent": 30,
      "description": "Complete math and science homework assignments.",
      "categoryId": 2,
      "completedOn": ""
    }
  ],
  "categories": [
    {
      "id": 1,
      "name": "cleaning",
      "color": "#FF5733"
    },
    {
      "id": 2,
      "name": "school",
      "color": "#33C1FF"
    }
  ]
}
```


### GET /index.php?id=:id

Returns one task by ID.

URL parameters:

id integer required The ID of the task to retrieve

Request body:

None.

Success response — 200 OK:

```json
{
  "id": 2,
  "name": "Finish homework",
  "status": "In Progress",
  "dueDate": "2023-10-12",
  "estimatedTime": 120,
  "timeSpent": 30,
  "description": "Complete math and science homework assignments.",
  "categoryId": 2,
  "completedOn": ""
}
```

Error response — 404 Not Found:

```json
{
  "error": "Task not found"
}
```


### POST /index.php

Creates a new task.

Request body JSON:

name string required Name of the task  
status string required Task status: Not Started, In Progress, or Completed  
dueDate date required Date the task is due  
estimatedTime integer required How much time is estimated to complete the task  
timeSpent integer optional How much time has been spent working on the task  
description string optional Gives instructions or a description of the task  
categoryId integer required ID of the category assigned to the task  
completedOn date optional Date the task status was marked as completed; required only when status is Completed

Success response — 201 Created:

```json
{
  "id": 4,
  "name": "Study for test",
  "status": "Not Started",
  "dueDate": "2026-05-10",
  "estimatedTime": 90,
  "timeSpent": 0,
  "description": "Study chapters 1 through 4.",
  "categoryId": 2,
  "completedOn": ""
}
```

Error response — 400 Bad Request:

```json
{
  "error": "Validation failed",
  "fields": {
    "name": "Task name is required",
    "estimatedTime": "Estimated time must be greater than zero"
  }
}
```


### PUT /index.php?id=:id

Updates an existing task by ID.

URL parameters:

id integer required The ID of the task to update

Request body JSON:

name string optional Name of the task  
status string optional Task status: Not Started, In Progress, or Completed  
dueDate date optional Date the task is due  
estimatedTime integer optional How much time is estimated to complete the task  
timeSpent integer optional How much time has been spent working on the task  
description string optional Gives instructions or a description of the task  
categoryId integer optional ID of the category assigned to the task  
completedOn date optional Date the task status was marked as completed; required only when status is Completed

Example request body:

```json
{
  "status": "Completed",
  "completedOn": "2026-05-05"
}
```

Success response — 200 OK:

```json
{
  "id": 2,
  "name": "Finish homework",
  "status": "Completed",
  "dueDate": "2023-10-12",
  "estimatedTime": 120,
  "timeSpent": 30,
  "description": "Complete math and science homework assignments.",
  "categoryId": 2,
  "completedOn": "2026-05-05"
}
```

Error response — 400 Bad Request:

```json
{
  "error": "Task ID is required"
}
```

Error response — 404 Not Found:

```json
{
  "error": "Task not found"
}
```


### DELETE /index.php?id=:id

Deletes a task by ID.

URL parameters:

id integer required The ID of the task to delete

Request body:

None.

Success response — 200 OK:

```json
{
  "message": "Task deleted successfully"
}
```

Error response — 400 Bad Request:

```json
{
  "error": "Task ID is required"
}
```

Error response — 404 Not Found:

```json
{
  "error": "Task not found"
}
```


## Category Endpoints

### POST /index.php?resource=categories

Creates a new category.

URL parameters:

resource string required Must be categories

Request body JSON:

name string required Name of the category  
color string required Hex color value, such as #FF5733

Success response — 201 Created:

```json
{
  "id": 3,
  "name": "work",
  "color": "#22AA88"
}
```

Error response — 400 Bad Request:

```json
{
  "error": "Validation failed",
  "fields": {
    "name": "Category name is required",
    "color": "Color must be a valid hex color, like #FF5733"
  }
}
```


### PUT /index.php?resource=categories&id=:id

Updates an existing category by ID.

URL parameters:

resource string required Must be categories  
id integer required The ID of the category to update

Request body JSON:

name string required Name of the category  
color string required Hex color value, such as #FF5733

Example request body:

```json
{
  "name": "home",
  "color": "#AA22FF"
}
```

Success response — 200 OK:

```json
{
  "id": 1,
  "name": "home",
  "color": "#AA22FF"
}
```

Error response — 400 Bad Request:

```json
{
  "error": "Category ID is required"
}
```

Error response — 404 Not Found:

```json
{
  "error": "Category not found"
}
```


### DELETE /index.php?resource=categories&id=:id

Deletes a category by ID.

URL parameters:

resource string required Must be categories  
id integer required The ID of the category to delete

Request body:

None.

Success response — 200 OK:

```json
{
  "message": "Category deleted successfully"
}
```

Error response — 400 Bad Request:

```json
{
  "error": "Category ID is required"
}
```

Error response — 404 Not Found:

```json
{
  "error": "Category not found"
}
```