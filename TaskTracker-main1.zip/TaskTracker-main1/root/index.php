<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/categoryModal.css">
    <link rel="stylesheet" href="css/newTask.css">
    <link rel="stylesheet" href="css/completedTasks.css">
    <script src="scripts/data.js" defer></script>
    <script src="scripts/categories.js" defer></script>
    <script src="scripts/newTask.js" defer></script>
    <script src="scripts/completedTasks.js" defer></script>
</head>
<body>
    <h1 class="title">Task Manager</h1>
    <div class="header">
        <label for="search">Search:</label>
        <input type="text" id="searchLabel" >
        
         <label for="sortBy">Sort By:</label>
    <select id="sortBy">
        <option value="name">Name</option>
        <option value="status">Status</option>
        <option value="category">Category</option>
        <option value="date">Date</option>
        <option value="estTime">Est. Time</option>
    </select>

    <select id="orderBy">
        <option value="ascending">Ascending</option>
        <option value="descending">Descending</option>
    </select>

    <div class="new-task-wrapper">
        <span class="btn-label">New Task</span>
        <button id="newTask">+</button>
    </div>

    <button id="category">Edit Categories</button>
</div>

<!-- this gets filled with the tasks -->
    <div id="tasks-container">
       
    </div>

<!-- Modal for new task -->
<div id="modalNewTask" class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>

    <label for="taskName">Task Name:</label>
    <input type="text" id="taskName">

    <label for="taskCategory">Task Category:</label>
    <select id="taskCategory"></select>

    <label for="taskDueDate">Task Due Date:</label>
    <input type="date" id="taskDueDate">

    <label for="taskEstTime">Task Est. Time (mins):</label>
    <input type="number" id="taskEstTime">

    <label for="taskDescription">Task Description:</label>
    <textarea id="taskDescription"></textarea>

    <button id="addTask" type="button">Add Task</button>
  </div>
</div>



<!-- Modal for categories -->
<div id="modalCategory" class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <div id="category-container"></div>
  </div>
</div>


<button id="viewCompleted">View Completed Tasks</button>

   <!-- Modal for completed tasks -->
<div id="modalCompleted" class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <div id="completed-container"></div>
  </div>
</div>

</body>
</html>