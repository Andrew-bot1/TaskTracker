<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>

    <link rel="stylesheet" href="css/styles.css">
</head>
<body>

    <h1 class="title">Sign Up</h1>

    <div class="login">
       <form action="../php-rest-api/api/signup.php" method="post">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <br><br>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <br><br>

            <label for="confirmPassword">Confirm Password:</label>
            <input type="password" id="confirmPassword" name="confirmPassword" required>

            <br><br>

            <button type="submit">Create Account</button>
        </form>

        <p>
            Already have an account?
            <a href="login.php">Login here</a>
        </p>
    </div>

</body>
</html>