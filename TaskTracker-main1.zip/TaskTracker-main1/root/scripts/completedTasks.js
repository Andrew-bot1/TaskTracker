document.addEventListener("DOMContentLoaded", () => {
    const completedModal = document.getElementById("modalCompleted");
    const completedBtn = document.getElementById("viewCompleted");
    const completedClose = document.querySelector("#modalCompleted .close");

    if (completedBtn && completedModal) {
        completedBtn.addEventListener("click", () => {
            completedModal.style.display = "block";
            loadCompletedTasks();
        });
    }

    if (completedClose && completedModal) {
        completedClose.addEventListener("click", () => {
            completedModal.style.display = "none";
        });
    }

    window.addEventListener("click", (event) => {
        if (completedModal && event.target === completedModal) {
            completedModal.style.display = "none";
        }
    });

    loadCompletedTasks();
});

function renderCompletedTasks(data) {
    const completedContainer = document.getElementById("completed-container");

    if (!completedContainer) {
        console.error("completed-container was not found.");
        return;
    }

    completedContainer.innerHTML = "";

    let tasks = [];

    if (Array.isArray(data)) {
        tasks = data;
    } else if (data.tasks && Array.isArray(data.tasks)) {
        tasks = data.tasks;
    }

    if (tasks.length === 0) {
        completedContainer.innerHTML = "<p>No completed tasks available.</p>";
        return;
    }
let html = "";

tasks.forEach(task => {
    if (task.status_name !== "Done" && task.status_id != 3) {
        return;
    }

    html += `
        <div class="completed-task-item">
            <h3>${task.title ?? "Untitled Task"}</h3>
            <p><strong>Due Date:</strong> ${task.due_date ?? "No due date"}</p>
            <p><strong>Time Spent:</strong> ${task.time_spent ?? 0} minutes</p>
            <p><strong>Completed On:</strong> ${task.completed_on ?? "Not completed"}</p>
            <p><strong>Category:</strong> ${task.category_name ?? "No category"}</p>
            <p><strong>Status:</strong> ${task.status_name ?? "No status"}</p>
        </div>
    `;
});

if (html === "") {
    completedContainer.innerHTML = "<p>No completed tasks available.</p>";
    return;
}

completedContainer.innerHTML = html;
}

function loadCompletedTasks() {
    fetch("../php-rest-api/index.php?resource=completed")
        .then(res => res.text())
        .then(text => {
            console.log("RAW COMPLETED TASKS RESPONSE:", text);

            const data = JSON.parse(text);

            renderCompletedTasks(data);
        })
        .catch(err => {
            console.error("Completed tasks load failed:", err);

            const completedContainer = document.getElementById("completed-container");

            if (completedContainer) {
                completedContainer.innerHTML = "<p>Error loading completed tasks.</p>";
            }
        });
}