console.log("newTask.js loaded");

document.addEventListener("DOMContentLoaded", () => {
    const newTaskModal = document.getElementById("modalNewTask");
    const newTaskBtn = document.getElementById("newTask");
    const newTaskClose = document.querySelector("#modalNewTask .close");
    const addTaskBtn = document.getElementById("addTask");

    if (newTaskBtn && newTaskModal) {
        newTaskBtn.addEventListener("click", () => {
            console.log("New Task button clicked");
            newTaskModal.style.display = "block";
            loadNewTaskCategories();
        });
    }

    if (newTaskClose && newTaskModal) {
        newTaskClose.addEventListener("click", () => {
            newTaskModal.style.display = "none";
        });
    }

    window.addEventListener("click", (event) => {
        if (newTaskModal && event.target === newTaskModal) {
            newTaskModal.style.display = "none";
        }
    });

    if (addTaskBtn) {
        addTaskBtn.addEventListener("click", createTask);
    } else {
        console.error("addTask button was not found.");
    }
});

function loadNewTaskCategories() {
    const categorySelect = document.getElementById("taskCategory");

    if (!categorySelect) {
        console.error("taskCategory select was not found.");
        return;
    }

    fetch("../php-rest-api/index.php?resource=categories")
        .then(res => res.text())
        .then(text => {
            console.log("RAW NEW TASK CATEGORY RESPONSE:", text);

            const data = JSON.parse(text);

            categorySelect.innerHTML = "";

            if (data.categories && data.categories.length > 0) {
                data.categories.forEach(category => {
                    categorySelect.innerHTML += `
                        <option value="${category.id}">
                            ${category.name}
                        </option>
                    `;
                });
            } else {
                categorySelect.innerHTML = `
                    <option value="">No categories available</option>
                `;
            }
        })
        .catch(err => {
            console.error("Failed to load categories for new task:", err);
        });
}

function createTask() {
    console.log("Add Task button clicked");

    const titleInput = document.getElementById("taskName");
    const categoryInput = document.getElementById("taskCategory");
    const dueDateInput = document.getElementById("taskDueDate");
    const estTimeInput = document.getElementById("taskEstTime");
    const descriptionInput = document.getElementById("taskDescription");

    const title = titleInput.value.trim();
    const categoryId = categoryInput.value;
    const dueDate = dueDateInput.value;
    const estimatedTime = estTimeInput.value;
    const description = descriptionInput.value.trim();

    if (!title) {
        alert("Task name is required.");
        return;
    }

    const newTask = {
        title: title,
        description: description,
        due_date: dueDate || null,
        estimated_time: estimatedTime || null,
        time_spent: 0,
        completed_on: null,
        category_id: categoryId || null,
        status_id: 1
    };

    console.log("TASK BEING CREATED:", newTask);

    fetch("../php-rest-api/index.php?resource=tasks", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(newTask)
    })
        .then(res => res.text())
        .then(text => {
            console.log("RAW CREATE TASK RESPONSE:", text);

            const data = JSON.parse(text);
            console.log("CREATE TASK DATA:", data);

            titleInput.value = "";
            dueDateInput.value = "";
            estTimeInput.value = "";
            descriptionInput.value = "";

            document.getElementById("modalNewTask").style.display = "none";

            if (typeof loadTasks === "function") {
                loadTasks();
            }
        })
        .catch(err => {
            console.error("Create task failed:", err);
        });
}