let activeTimerIntervals = {};

let currentData = {
    tasks: [],
    categories: []
};

document.addEventListener("DOMContentLoaded", () => {
    console.log("DOM loaded, now loading tasks");

    const searchInput = document.getElementById("searchLabel");
    const sortBy = document.getElementById("sortBy");
    const orderBy = document.getElementById("orderBy");

    if (searchInput) {
        searchInput.addEventListener("input", applySearchAndSort);
    }

    if (sortBy) {
        sortBy.addEventListener("change", applySearchAndSort);
    }

    if (orderBy) {
        orderBy.addEventListener("change", applySearchAndSort);
    }

    loadTasks();
});

function loadTasks() {
    console.log("loadTasks is running");

    Promise.all([
        fetch("../php-rest-api/index.php?resource=tasks").then(res => res.text()),
        fetch("../php-rest-api/index.php?resource=categories").then(res => res.text())
    ])
    .then(([taskText, categoryText]) => {
        console.log("RAW TASK RESPONSE:", taskText);
        console.log("RAW CATEGORY RESPONSE:", categoryText);

        const taskData = JSON.parse(taskText);
        const categoryData = JSON.parse(categoryText);

        currentData = {
            tasks: taskData.tasks ?? [],
            categories: categoryData.categories ?? []
        };

        applySearchAndSort();
    })
    .catch(err => {
        console.error("Data load failed:", err);

        const container = document.getElementById("tasks-container");

        if (container) {
            container.innerHTML = "<p>Error loading tasks. Please try again later.</p>";
        }
    });
}

function applySearchAndSort() {
    const searchInput = document.getElementById("searchLabel");
    const sortBySelect = document.getElementById("sortBy");
    const orderBySelect = document.getElementById("orderBy");

    const searchText = searchInput ? searchInput.value.toLowerCase().trim() : "";
    const sortBy = sortBySelect ? sortBySelect.value : "name";
    const orderBy = orderBySelect ? orderBySelect.value : "ascending";

    let filteredTasks = [...currentData.tasks];

    if (searchText !== "") {
        filteredTasks = filteredTasks.filter(task => {
            const title = (task.title ?? "").toLowerCase();
            const description = (task.description ?? "").toLowerCase();
            const status = (task.status_name ?? "").toLowerCase();
            const category = (task.category_name ?? "").toLowerCase();
            const dueDate = (task.due_date ?? "").toLowerCase();
            const estimatedTime = String(task.estimated_time ?? "").toLowerCase();

            return (
                title.includes(searchText) ||
                description.includes(searchText) ||
                status.includes(searchText) ||
                category.includes(searchText) ||
                dueDate.includes(searchText) ||
                estimatedTime.includes(searchText)
            );
        });
    }

    filteredTasks.sort((a, b) => {
        let valueA;
        let valueB;

        if (sortBy === "name") {
            valueA = (a.title ?? "").toLowerCase();
            valueB = (b.title ?? "").toLowerCase();
        } else if (sortBy === "status") {
            valueA = (a.status_name ?? "").toLowerCase();
            valueB = (b.status_name ?? "").toLowerCase();
        } else if (sortBy === "category") {
            valueA = (a.category_name ?? "").toLowerCase();
            valueB = (b.category_name ?? "").toLowerCase();
        } else if (sortBy === "date") {
            valueA = a.due_date ?? "";
            valueB = b.due_date ?? "";
        } else if (sortBy === "estTime") {
            valueA = Number(a.estimated_time ?? 0);
            valueB = Number(b.estimated_time ?? 0);
        } else {
            valueA = "";
            valueB = "";
        }

        if (valueA < valueB) {
            return orderBy === "ascending" ? -1 : 1;
        }

        if (valueA > valueB) {
            return orderBy === "ascending" ? 1 : -1;
        }

        return 0;
    });

    renderTasks({
        tasks: filteredTasks,
        categories: currentData.categories
    });
}

function renderTasks(data) {
    const container = document.getElementById("tasks-container");

    if (!container) {
        console.error("tasks-container was not found.");
        return;
    }

    container.innerHTML = "";

    let html = "";

    if (data.tasks && data.tasks.length !== 0) {
        data.tasks.forEach(task => {
            console.log("TASK:", task);

            if (task.status_name === "Done" || task.status_id == 3) {
                return;
            }

            let categoriesOptions = "";

            if (data.categories && data.categories.length !== 0) {
                data.categories.forEach(category => {
                    categoriesOptions += `
                        <option 
                            value="${category.id}" 
                            ${task.category_id == category.id ? "selected" : ""}
                            style="background-color: ${category.color};">
                            ${category.name}
                        </option>
                    `;
                });
            }

            html += `
                <div class="flip-card" data-id="${task.id}">
                    <div class="flip-card-inner">

                        <div class="flip-card-front">

                            <div class="task-view">
                                <h2>${task.title ?? "Untitled Task"}</h2>
                                <p><strong>Category:</strong> ${task.category_name ?? "No category"}</p>
                                <p><strong>Status:</strong> ${task.status_name ?? "No status"}</p>
                                <p><strong>Due Date:</strong> ${task.due_date ?? "No due date"}</p>
                                <p><strong>Est. Time:</strong> ${task.estimated_time ?? 0} min</p>

                                <p>
                                    <strong>Spent:</strong> 
                                    <span 
                                        class="time-spent-display" 
                                        data-base-seconds="${task.time_spent ?? 0}">
                                        ${formatSeconds(task.time_spent ?? 0)}
                                    </span>
                                </p>
                            </div>

                            <div class="task-edit" style="display:none;">
                                <label>Title</label>
                                <input 
                                    class="task-title" 
                                    type="text" 
                                    value="${task.title ?? ""}"
                                >

                                <label>Category</label>
                                <select class="task-category">
                                    ${categoriesOptions}
                                </select>

                                <label>Status</label>
                                <select class="task-status">
                                    <option value="1" ${task.status_id == 1 ? "selected" : ""}>To Do</option>
                                    <option value="2" ${task.status_id == 2 ? "selected" : ""}>In Progress</option>
                                    <option value="3" ${task.status_id == 3 ? "selected" : ""}>Done</option>
                                </select>

                                <label>Due Date</label>
                                <input 
                                    class="task-due-date" 
                                    type="date" 
                                    value="${task.due_date ?? ""}"
                                >

                                <label>Est. Time</label>
                                <input 
                                    class="task-estimated-time" 
                                    type="number" 
                                    value="${task.estimated_time ?? 0}" 
                                    min="0"
                                >
                            </div>

                        </div>

                        <div class="flip-card-back">

                            <div class="task-back-view">
                                <h1>${task.title ?? "Untitled Task"}</h1>
                                <p>${task.description ?? "No description"}</p>
                            </div>

                            <div class="task-back-edit" style="display:none;">
                                <label>Description</label>
                                <textarea class="task-description">${task.description ?? ""}</textarea>
                            </div>

                        </div>

                    </div>

                    <div class="task-buttons">
                        <button 
                            class="btnFlip"
                            onclick="this.closest('.flip-card').querySelector('.flip-card-inner')?.classList.toggle('flipped')">
                            <img src="images/flip.png" alt="Flip">
                        </button>

                        <button 
                            class="timer"
                            data-running="false"
                            onclick="toggleTimer(${task.id}, event)">
                            Start Timer
                        </button>

                        <button 
                            class="edit-save" 
                            onclick="toggleEditSave(${task.id}, event)">
                            Edit
                        </button>

                        <button 
                            class="delete" 
                            onclick="deleteTask(${task.id})">
                            Delete
                        </button>
                    </div>
                </div>
            `;
        });

        if (html === "") {
            container.innerHTML = "<p>No active tasks available.</p>";
            return;
        }

        container.innerHTML = html;
    } else {
        container.innerHTML = "<p>No tasks available.</p>";
    }
}

function toggleEditSave(id, event) {
    const button = event.target;
    const card = button.closest(".flip-card");

    if (!card) {
        console.error("Could not find task card.");
        return;
    }

    const viewSection = card.querySelector(".task-view");
    const editSection = card.querySelector(".task-edit");
    const backViewSection = card.querySelector(".task-back-view");
    const backEditSection = card.querySelector(".task-back-edit");

    if (button.textContent.trim() === "Edit") {
        viewSection.style.display = "none";
        editSection.style.display = "block";

        backViewSection.style.display = "none";
        backEditSection.style.display = "block";

        button.textContent = "Save";
        return;
    }

    saveTask(id, card);
}

function saveTask(id, card) {
    const title = card.querySelector(".task-title").value.trim();
    const categoryId = card.querySelector(".task-category").value;
    const statusId = card.querySelector(".task-status").value;
    const dueDate = card.querySelector(".task-due-date").value;
    const estimatedTime = card.querySelector(".task-estimated-time").value;
    const description = card.querySelector(".task-description").value.trim();

    if (!title) {
        alert("Task title is required.");
        return;
    }

    const completedOn = statusId == 3 ? new Date().toISOString().split("T")[0] : null;

    fetch(`../php-rest-api/index.php?resource=tasks&id=${id}`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            title: title,
            description: description,
            due_date: dueDate || null,
            estimated_time: estimatedTime || null,
            category_id: categoryId || null,
            status_id: statusId,
            completed_on: completedOn
        })
    })
    .then(res => res.text())
    .then(text => {
        console.log("RAW SAVE TASK RESPONSE:", text);

        const data = JSON.parse(text);
        console.log("SAVE TASK DATA:", data);

        loadTasks();

        if (typeof loadCompletedTasks === "function") {
            loadCompletedTasks();
        }
    })
    .catch(err => {
        console.error("Save task failed:", err);
    });
}

function deleteTask(id) {
    if (!confirm("Delete this task?")) {
        return;
    }

    fetch(`../php-rest-api/index.php?resource=tasks&id=${id}`, {
        method: "DELETE"
    })
    .then(res => res.text())
    .then(text => {
        console.log("RAW DELETE RESPONSE:", text);

        const data = JSON.parse(text);
        console.log("DELETE TASK DATA:", data);

        loadTasks();
    })
    .catch(err => {
        console.error("Delete failed:", err);
    });
}

function toggleTimer(taskId, event) {
    const button = event.target;
    const isRunning = button.dataset.running === "true";

    if (!isRunning) {
        startTimer(taskId, button);
    } else {
        stopTimer(taskId, button);
    }
}

function startTimer(taskId, button) {
    fetch("../php-rest-api/index.php?resource=timer", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            task_id: taskId,
            action: "start"
        })
    })
    .then(res => res.text())
    .then(text => {
        console.log("RAW START TIMER RESPONSE:", text);

        const data = JSON.parse(text);
        console.log("START TIMER DATA:", data);

        if (data.status === "success") {
            button.dataset.running = "true";
            button.textContent = "Stop Timer";

            const card = button.closest(".flip-card");
            const spentDisplay = card.querySelector(".time-spent-display");

            const baseSeconds = Number(spentDisplay.dataset.baseSeconds ?? 0);
            const startTime = Date.now();

            activeTimerIntervals[taskId] = setInterval(() => {
                const elapsedSeconds = Math.floor((Date.now() - startTime) / 1000);
                spentDisplay.textContent = formatSeconds(baseSeconds + elapsedSeconds);
            }, 1000);
        }
    })
    .catch(err => {
        console.error("Start timer failed:", err);
    });
}

function stopTimer(taskId, button) {
    fetch("../php-rest-api/index.php?resource=timer", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            task_id: taskId,
            action: "stop"
        })
    })
    .then(res => res.text())
    .then(text => {
        console.log("RAW STOP TIMER RESPONSE:", text);

        const data = JSON.parse(text);
        console.log("STOP TIMER DATA:", data);

        if (data.status === "success") {
            button.dataset.running = "false";
            button.textContent = "Start Timer";

            if (activeTimerIntervals[taskId]) {
                clearInterval(activeTimerIntervals[taskId]);
                delete activeTimerIntervals[taskId];
            }

            loadTasks();
        }
    })
    .catch(err => {
        console.error("Stop timer failed:", err);
    });
}

function formatSeconds(totalSeconds) {
    totalSeconds = Number(totalSeconds ?? 0);

    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    if (hours > 0) {
        return `${hours}h ${minutes}m ${seconds}s`;
    }

    if (minutes > 0) {
        return `${minutes}m ${seconds}s`;
    }

    return `${seconds}s`;
}