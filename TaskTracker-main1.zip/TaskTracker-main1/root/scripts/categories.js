document.addEventListener("DOMContentLoaded", () => {
    const categoryModal = document.getElementById("modalCategory");
    const categoryBtn = document.getElementById("category");
    const categoryClose = document.querySelector("#modalCategory .close");
    const categoryContainer = document.getElementById("category-container");

    if (categoryBtn && categoryModal) {
        categoryBtn.addEventListener("click", () => {
            categoryModal.style.display = "block";
            loadCategories();
        });
    }

    if (categoryClose && categoryModal) {
        categoryClose.addEventListener("click", () => {
            categoryModal.style.display = "none";
        });
    }

    window.addEventListener("click", (event) => {
        if (categoryModal && event.target === categoryModal) {
            categoryModal.style.display = "none";
        }
    });

    if (categoryContainer) {
        categoryContainer.addEventListener("click", (e) => {
            if (e.target.id === "addCategory") {
                showAddCategoryForm();
            }

            if (e.target.id === "saveNewCategory") {
                createCategory();
            }

            if (e.target.id === "cancelNewCategory") {
                loadCategories();
            }

            if (e.target.classList.contains("save-category")) {
                const item = e.target.closest(".category-item");

                if (item) {
                    updateCategory(item);
                }
            }

            if (e.target.classList.contains("delete-category")) {
                const item = e.target.closest(".category-item");

                if (item) {
                    deleteCategory(item.dataset.id);
                }
            }
        });
    }

    loadCategories();
});

function loadCategories() {
    fetch("../php-rest-api/index.php?resource=categories")
        .then(res => res.text())
        .then(text => {
            console.log("RAW CATEGORY RESPONSE:", text);

            const data = JSON.parse(text);

            renderCategories(data);
        })
        .catch(err => {
            console.error("Category load failed:", err);

            const categoryContainer = document.getElementById("category-container");

            if (categoryContainer) {
                categoryContainer.innerHTML = `
                    <p>Error loading categories. Check console for raw PHP response.</p>
                `;
            }
        });
}

function renderCategories(data) {
    const categoryContainer = document.getElementById("category-container");

    if (!categoryContainer) {
        console.error("category-container not found.");
        return;
    }

    let categories = [];

    if (Array.isArray(data)) {
        categories = data;
    } else if (data.categories && Array.isArray(data.categories)) {
        categories = data.categories;
    }

    let html = `
        <button id="addCategory" type="button">Add Category</button>
    `;

    if (categories.length === 0) {
        html += `<p>No categories available.</p>`;
        categoryContainer.innerHTML = html;
        return;
    }

    categories.forEach(category => {
        html += `
            <div class="category-item" data-id="${category.id}">
                <label>Name</label>
                <input 
                    type="text" 
                    class="category-name" 
                    value="${category.name ?? ""}"
                >

                <label>Color</label>
                <input 
                    type="color" 
                    class="category-color" 
                    value="${category.color ?? "#000000"}"
                >

                <button type="button" class="save-category">Save</button>
                <button type="button" class="delete-category">Delete</button>
            </div>
        `;
    });

    categoryContainer.innerHTML = html;
}

function showAddCategoryForm() {
    const categoryContainer = document.getElementById("category-container");

    categoryContainer.innerHTML = `
        <div class="category-item">
            <label>Name</label>
            <input type="text" id="newCatName" placeholder="Category name">

            <label>Color</label>
            <input type="color" id="newCatColor" value="#000000">

            <button type="button" id="saveNewCategory">Save Category</button>
            <button type="button" id="cancelNewCategory">Cancel</button>
        </div>
    `;
}

function createCategory() {
    const nameInput = document.getElementById("newCatName");
    const colorInput = document.getElementById("newCatColor");

    const name = nameInput.value.trim();
    const color = colorInput.value;

    if (!name) {
        alert("Category name is required.");
        return;
    }

    fetch("../php-rest-api/index.php?resource=categories", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            name: name,
            color: color
        })
    })
        .then(res => res.text())
        .then(text => {
            console.log("RAW CREATE CATEGORY RESPONSE:", text);

            const data = JSON.parse(text);
            console.log("CREATE CATEGORY DATA:", data);

            loadCategories();

            if (typeof loadTasks === "function") {
                loadTasks();
            }
        })
        .catch(err => {
            console.error("Create category failed:", err);
        });
}

function updateCategory(item) {
    const id = item.dataset.id;
    const name = item.querySelector(".category-name").value.trim();
    const color = item.querySelector(".category-color").value;

    if (!name) {
        alert("Category name is required.");
        return;
    }

    fetch(`../php-rest-api/index.php?resource=categories&id=${id}`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            name: name,
            color: color
        })
    })
        .then(res => res.text())
        .then(text => {
            console.log("RAW UPDATE CATEGORY RESPONSE:", text);

            const data = JSON.parse(text);
            console.log("UPDATE CATEGORY DATA:", data);

            loadCategories();

            if (typeof loadTasks === "function") {
                loadTasks();
            }
        })
        .catch(err => {
            console.error("Update category failed:", err);
        });
}

function deleteCategory(id) {
    if (!confirm("Delete this category?")) {
        return;
    }

    fetch(`../php-rest-api/index.php?resource=categories&id=${id}`, {
        method: "DELETE"
    })
        .then(res => res.text())
        .then(text => {
            console.log("RAW DELETE CATEGORY RESPONSE:", text);

            const data = JSON.parse(text);
            console.log("DELETE CATEGORY DATA:", data);

            loadCategories();

            if (typeof loadTasks === "function") {
                loadTasks();
            }
        })
        .catch(err => {
            console.error("Delete category failed:", err);
        });
}