<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <link rel="stylesheet" href="css/styles.css">
</head>
<body>

    <h1 class="title">Login</h1>

    <div class="login">
        <form action="../php-rest-api/api/login.php" method="post">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <br><br>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <br><br>

            <button type="submit">Login</button>
        </form>

        <p>
            Don't have an account?
            <a href="signup.php">Sign up here</a>
        </p>
    </div>

</body>
</html>