<?php

function validateTask($data) {
    $errors = [];

    // Trim string fields
    $title = trim($data["title"] ?? "");
    $description = trim($data["description"] ?? "");
    $dueDate = trim($data["due_date"] ?? "");
    $completedOn = trim($data["completed_on"] ?? "");

    // Title validation
    if ($title === "") {
        $errors["title"] = "Task title is required";
    } elseif (strlen($title) > 255) {
        $errors["title"] = "Task title must be 255 characters or less";
    }

    // Description validation
    if (strlen($description) > 1000) {
        $errors["description"] = "Description must be 1000 characters or less";
    }

    // Due date validation
    if ($dueDate !== "") {
    if (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $dueDate)) {
        $errors["due_date"] = "Due date must be in YYYY-MM-DD format";
    } else {
        $today = date("Y-m-d");

        if ($dueDate < $today) {
            $errors["due_date"] = "Due date cannot be in the past";
        }
    }
}
    // Estimated time validation
    if (isset($data["estimated_time"]) && $data["estimated_time"] !== "") {
        if (!is_numeric($data["estimated_time"])) {
            $errors["estimated_time"] = "Estimated time must be a number";
        } elseif ((int)$data["estimated_time"] <= 0) {
            $errors["estimated_time"] = "Estimated time must be greater than zero";
        }
    }

    // Time spent validation
    if (isset($data["time_spent"]) && $data["time_spent"] !== "") {
        if (!is_numeric($data["time_spent"])) {
            $errors["time_spent"] = "Time spent must be a number";
        } elseif ((int)$data["time_spent"] < 0) {
            $errors["time_spent"] = "Time spent cannot be negative";
        }
    }

    // Category ID validation
    if (isset($data["category_id"]) && $data["category_id"] !== "" && $data["category_id"] !== null) {
        if (!is_numeric($data["category_id"])) {
            $errors["category_id"] = "Category ID must be a number";
        }
    }

    // Status ID validation
    if (isset($data["status_id"]) && $data["status_id"] !== "" && $data["status_id"] !== null) {
        if (!is_numeric($data["status_id"])) {
            $errors["status_id"] = "Status ID must be a number";
        }
    }

    // Completed date validation
    if ($completedOn !== "" && !preg_match("/^\d{4}-\d{2}-\d{2}$/", $completedOn)) {
        $errors["completed_on"] = "Completed date must be in YYYY-MM-DD format";
    }

    return $errors;
}

function validateCategory($data) {
    $errors = [];

    $name = trim($data["name"] ?? "");
    $color = trim($data["color"] ?? "");

    if ($name === "") {
        $errors["name"] = "Category name is required";
    } elseif (strlen($name) > 255) {
        $errors["name"] = "Category name must be 255 characters or less";
    }

    if ($color === "") {
        $errors["color"] = "Category color is required";
    } elseif (!preg_match("/^#[0-9A-Fa-f]{6}$/", $color)) {
        $errors["color"] = "Color must be a valid hex color, like #FF5733";
    }

    return $errors;
}