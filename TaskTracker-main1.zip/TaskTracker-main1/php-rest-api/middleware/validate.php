<?php

function validateTask($data) {
    $errors = [];

    if (!isset($data["name"]) || trim($data["name"]) === "") {
        $errors["name"] = "Task name is required";
    }

    if (!isset($data["status"]) || trim($data["status"]) === "") {
        $errors["status"] = "Status is required";
    } else {
        $validStatuses = ["Not Started", "In Progress", "Completed"];

        if (!in_array($data["status"], $validStatuses)) {
            $errors["status"] = "Status must be Not Started, In Progress, or Completed";
        }
    }

    if (!isset($data["dueDate"]) || trim($data["dueDate"]) === "") {
        $errors["dueDate"] = "Due date is required";
    } elseif (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $data["dueDate"])) {
        $errors["dueDate"] = "Due date must be in YYYY-MM-DD format";
    }

    if (!isset($data["estimatedTime"])) {
        $errors["estimatedTime"] = "Estimated time is required";
    } elseif (!is_int($data["estimatedTime"])) {
        $errors["estimatedTime"] = "Estimated time must be an integer";
    } elseif ($data["estimatedTime"] <= 0) {
        $errors["estimatedTime"] = "Estimated time must be greater than zero";
    }

    if (isset($data["timeSpent"])) {
        if (!is_int($data["timeSpent"])) {
            $errors["timeSpent"] = "Time spent must be an integer";
        } elseif ($data["timeSpent"] < 0) {
            $errors["timeSpent"] = "Time spent cannot be negative";
        }
    }

    if (!isset($data["categoryId"])) {
        $errors["categoryId"] = "Category ID is required";
    } elseif (!is_int($data["categoryId"])) {
        $errors["categoryId"] = "Category ID must be an integer";
    }

    // Business rule
    if (isset($data["status"]) && $data["status"] === "Completed") {
        if (!isset($data["completedOn"]) || trim($data["completedOn"]) === "") {
            $errors["completedOn"] = "Completed tasks must include a completedOn date";
        }
    }

    return $errors;
}

function validateCategory($data) {
    $errors = [];

    if (!isset($data["name"]) || trim($data["name"]) === "") {
        $errors["name"] = "Category name is required";
    }

    if (!isset($data["color"]) || trim($data["color"]) === "") {
        $errors["color"] = "Category color is required";
    } elseif (!preg_match("/^#[0-9A-Fa-f]{6}$/", $data["color"])) {
        $errors["color"] = "Color must be a valid hex color, like #FF5733";
    }

    return $errors;
}