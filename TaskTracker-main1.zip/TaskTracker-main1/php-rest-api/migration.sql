CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    color VARCHAR(7) NOT NULL,

    FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS statuses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    due_date DATE,
    time_spent INT DEFAULT 0,
    estimated_time INT,
    completed_on DATE,
    category_id INT,
    status_id INT DEFAULT 1,

    FOREIGN KEY (user_id) REFERENCES users(id) 
        ON DELETE CASCADE,

    FOREIGN KEY (category_id) REFERENCES categories(id) 
        ON DELETE SET NULL,

    FOREIGN KEY (status_id) REFERENCES statuses(id) 
        ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS time_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    task_id INT NOT NULL,
    start_time DATETIME NOT NULL,
    end_time DATETIME NULL,

    FOREIGN KEY (task_id) REFERENCES tasks(id) 
        ON DELETE CASCADE
);