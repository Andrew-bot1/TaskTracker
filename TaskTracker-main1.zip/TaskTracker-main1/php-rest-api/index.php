<?php
session_start();

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    exit;
}

if (!isset($_SESSION["user_id"])) {
    http_response_code(401);
    echo json_encode([
        "status" => "error",
        "message" => "Not logged in"
    ]);
    exit;
}

require_once __DIR__ . '/data/store.php';

$request = $_SERVER['REQUEST_METHOD'];
$resource = $_GET['resource'] ?? 'tasks';

switch ($request) {
    case 'GET':
        require __DIR__ . '/api/get.php';
        break;

    case 'POST':
        if ($resource === 'timer') {
            require __DIR__ . '/api/timer.php';
        } elseif ($resource === 'categories') {
            require __DIR__ . '/api/categories/post.php';
        } else {
            require __DIR__ . '/api/post.php';
        }
        break;

    case 'PUT':
        if ($resource === 'categories') {
            require __DIR__ . '/api/categories/put.php';
        } else {
            require __DIR__ . '/api/put.php';
        }
        break;

    case 'DELETE':
        if ($resource === 'categories') {
            require __DIR__ . '/api/categories/delete.php';
        } else {
            require __DIR__ . '/api/delete.php';
        }
        break;

    default:
        http_response_code(405);
        echo json_encode([
            "status" => "error",
            "message" => "Invalid request method"
        ]);
        break;
}