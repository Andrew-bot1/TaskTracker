<?php
session_start();

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    exit;
}

require_once __DIR__ . '/data/store.php';

/*
    Temporary testing fallback.
    Remove this later when login fully works.
*/
if (!isset($_SESSION["user_id"])) {
    http_response_code(401);
    echo json_encode([
        "status" => "error",
        "message" => "Not logged in"
    ]);
    exit;
}

$request = $_SERVER['REQUEST_METHOD'];

switch ($request) {
    case 'GET':
        require __DIR__ . '/api/get.php';
        break;

    case 'POST':
        if (isset($_GET['resource']) && $_GET['resource'] === 'timer') {
           require __DIR__ . '/api/timer.php';
        } else if (isset($_GET['resource']) && $_GET['resource'] === 'categories') {
            require __DIR__ . '/api/categories/post.php';
        } else {
            require __DIR__ . '/api/post.php';
        }
        break;

    case 'PUT':
        if (isset($_GET['resource']) && $_GET['resource'] === 'categories') {
            require __DIR__ . '/api/categories/put.php';
        } else {
            require __DIR__ . '/api/put.php';
        }
        break;

    case 'DELETE':
        if (isset($_GET['resource']) && $_GET['resource'] === 'categories') {
            require __DIR__ . '/api/categories/delete.php';
        } else {
            require __DIR__ . '/api/delete.php';
        }
        break;

    default:
        http_response_code(405);
        echo json_encode([
            "status" => "error",
            "message" => "Invalid request method"
        ]);
}