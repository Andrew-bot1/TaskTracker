<?php

require_once __DIR__ . '/../db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/*
    TEMP USER ID FIX:
    If you do not have login working yet, this gives the app a default user_id.
    Make sure your users table has a user with id = 1.
*/
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 1;
}

function getAllTasks() {
    global $pdo;

    $sql = "SELECT 
                tasks.id,
                tasks.user_id,
                tasks.title,
                tasks.description,
                tasks.due_date,
                tasks.time_spent,
                tasks.estimated_time,
                tasks.completed_on,
                tasks.category_id,
                tasks.status_id,
                categories.name AS category_name,
                categories.color AS category_color,
                statuses.name AS status_name
            FROM tasks
            LEFT JOIN categories ON tasks.category_id = categories.id
            LEFT JOIN statuses ON tasks.status_id = statuses.id
            WHERE tasks.user_id = :user_id
            ORDER BY tasks.id DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':user_id' => $_SESSION['user_id']
    ]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getTaskById($id) {
    global $pdo;

    $sql = "SELECT 
                tasks.id,
                tasks.user_id,
                tasks.title,
                tasks.description,
                tasks.due_date,
                tasks.time_spent,
                tasks.estimated_time,
                tasks.completed_on,
                tasks.category_id,
                tasks.status_id,
                categories.name AS category_name,
                categories.color AS category_color,
                statuses.name AS status_name
            FROM tasks
            LEFT JOIN categories ON tasks.category_id = categories.id
            LEFT JOIN statuses ON tasks.status_id = statuses.id
            WHERE tasks.id = :id
            AND tasks.user_id = :user_id";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':id' => $id,
        ':user_id' => $_SESSION['user_id']
    ]);

    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function createTask($data) {
    global $pdo;

    $sql = "INSERT INTO tasks 
            (user_id, title, description, due_date, time_spent, estimated_time, completed_on, category_id, status_id) 
            VALUES 
            (:user_id, :title, :description, :due_date, :time_spent, :estimated_time, :completed_on, :category_id, :status_id)";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        ':user_id' => $_SESSION['user_id'],
        ':title' => $data['title'] ?? '',
        ':description' => $data['description'] ?? '',
        ':due_date' => empty($data['due_date']) ? null : $data['due_date'],
        ':time_spent' => $data['time_spent'] ?? 0,
        ':estimated_time' => empty($data['estimated_time']) ? null : $data['estimated_time'],
        ':completed_on' => empty($data['completed_on']) ? null : $data['completed_on'],
        ':category_id' => empty($data['category_id']) ? null : $data['category_id'],
        ':status_id' => empty($data['status_id']) ? null : $data['status_id']
    ]);

    $newId = $pdo->lastInsertId();

    return getTaskById($newId);
}

function updateTask($id, $data) {
    global $pdo;

    $existingTask = getTaskById($id);

    if (!$existingTask) {
        return null;
    }

    $title = $data['title'] ?? $existingTask['title'];
    $description = $data['description'] ?? $existingTask['description'];

    $due_date = array_key_exists('due_date', $data)
        ? (empty($data['due_date']) ? null : $data['due_date'])
        : $existingTask['due_date'];

    $time_spent = $data['time_spent'] ?? $existingTask['time_spent'];

    $estimated_time = array_key_exists('estimated_time', $data)
        ? (empty($data['estimated_time']) ? null : $data['estimated_time'])
        : $existingTask['estimated_time'];

    $completed_on = array_key_exists('completed_on', $data)
        ? (empty($data['completed_on']) ? null : $data['completed_on'])
        : $existingTask['completed_on'];

    $category_id = array_key_exists('category_id', $data)
        ? (empty($data['category_id']) ? null : $data['category_id'])
        : $existingTask['category_id'];

    $status_id = array_key_exists('status_id', $data)
        ? (empty($data['status_id']) ? null : $data['status_id'])
        : $existingTask['status_id'];

    $sql = "UPDATE tasks
            SET title = :title,
                description = :description,
                due_date = :due_date,
                time_spent = :time_spent,
                estimated_time = :estimated_time,
                completed_on = :completed_on,
                category_id = :category_id,
                status_id = :status_id
            WHERE id = :id
            AND user_id = :user_id";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        ':title' => $title,
        ':description' => $description,
        ':due_date' => $due_date,
        ':time_spent' => $time_spent,
        ':estimated_time' => $estimated_time,
        ':completed_on' => $completed_on,
        ':category_id' => $category_id,
        ':status_id' => $status_id,
        ':id' => $id,
        ':user_id' => $_SESSION['user_id']
    ]);

    return getTaskById($id);
}

function deleteTask($id) {
    global $pdo;

    $existingTask = getTaskById($id);

    if (!$existingTask) {
        return false;
    }

    $sql = "DELETE FROM tasks
            WHERE id = :id
            AND user_id = :user_id";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        ':id' => $id,
        ':user_id' => $_SESSION['user_id']
    ]);

    return true;
}

function getCompletedTasks() {
    global $pdo;

    $sql = "SELECT 
                tasks.id,
                tasks.user_id,
                tasks.title,
                tasks.description,
                tasks.due_date,
                tasks.time_spent,
                tasks.estimated_time,
                tasks.completed_on,
                tasks.category_id,
                tasks.status_id,
                categories.name AS category_name,
                categories.color AS category_color,
                statuses.name AS status_name
            FROM tasks
            LEFT JOIN categories ON tasks.category_id = categories.id
            LEFT JOIN statuses ON tasks.status_id = statuses.id
            WHERE tasks.user_id = :user_id
            AND tasks.completed_on IS NOT NULL
            ORDER BY tasks.completed_on DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':user_id' => $_SESSION['user_id']
    ]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getAllCategories() {
    global $pdo;

    $sql = "SELECT id, user_id, name, color
            FROM categories
            WHERE user_id = :user_id
            ORDER BY id DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':user_id' => $_SESSION['user_id']
    ]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getCategoryById($id) {
    global $pdo;

    $sql = "SELECT id, user_id, name, color
            FROM categories
            WHERE id = :id
            AND user_id = :user_id";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':id' => $id,
        ':user_id' => $_SESSION['user_id']
    ]);

    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function createCategory($data) {
    global $pdo;

    $sql = "INSERT INTO categories 
            (user_id, name, color)
            VALUES 
            (:user_id, :name, :color)";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        ':user_id' => $_SESSION['user_id'],
        ':name' => $data['name'],
        ':color' => $data['color']
    ]);

    $newId = $pdo->lastInsertId();

    return getCategoryById($newId);
}

function updateCategory($id, $data) {
    global $pdo;

    $oldCategory = getCategoryById($id);

    if (!$oldCategory) {
        return null;
    }

    $name = $data['name'] ?? $oldCategory['name'];
    $color = $data['color'] ?? $oldCategory['color'];

    $sql = "UPDATE categories
            SET name = :name,
                color = :color
            WHERE id = :id
            AND user_id = :user_id";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        ':id' => $id,
        ':user_id' => $_SESSION['user_id'],
        ':name' => $name,
        ':color' => $color
    ]);

    return getCategoryById($id);
}

function deleteCategory($id) {
    global $pdo;

    $category = getCategoryById($id);

    if (!$category) {
        return false;
    }

    /*
        Remove this category from the user's tasks first.
        This avoids foreign key errors when deleting a category.
    */
    $sql = "UPDATE tasks
            SET category_id = NULL
            WHERE category_id = :id
            AND user_id = :user_id";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':id' => $id,
        ':user_id' => $_SESSION['user_id']
    ]);

    $sql = "DELETE FROM categories 
            WHERE id = :id
            AND user_id = :user_id";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        ':id' => $id,
        ':user_id' => $_SESSION['user_id']
    ]);

    return $stmt->rowCount() > 0;
}

function getActiveTimeLog($taskId) {
    global $pdo;

    $task = getTaskById($taskId);

    if (!$task) {
        return null;
    }

    $sql = "SELECT *
            FROM time_logs
            WHERE task_id = :task_id
            AND end_time IS NULL
            ORDER BY start_time DESC
            LIMIT 1";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':task_id' => $taskId
    ]);

    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function startTaskTimer($taskId) {
    global $pdo;

    $task = getTaskById($taskId);

    if (!$task) {
        return null;
    }

    $activeLog = getActiveTimeLog($taskId);

    if ($activeLog) {
        return $activeLog;
    }

    $sql = "INSERT INTO time_logs
            (task_id, start_time, end_time)
            VALUES
            (:task_id, NOW(), NULL)";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':task_id' => $taskId
    ]);

    return getActiveTimeLog($taskId);
}

function stopTaskTimer($taskId) {
    global $pdo;

    $task = getTaskById($taskId);

    if (!$task) {
        return null;
    }

    $activeLog = getActiveTimeLog($taskId);

    if (!$activeLog) {
        return null;
    }

    $sql = "UPDATE time_logs
            SET end_time = NOW()
            WHERE id = :id";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':id' => $activeLog['id']
    ]);

    $sql = "SELECT TIMESTAMPDIFF(SECOND, start_time, end_time) AS seconds_spent
            FROM time_logs
            WHERE id = :id";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':id' => $activeLog['id']
    ]);

    $log = $stmt->fetch(PDO::FETCH_ASSOC);

    $secondsSpent = intval($log['seconds_spent'] ?? 0);

    if ($secondsSpent < 1) {
        $secondsSpent = 1;
    }

    $sql = "UPDATE tasks
            SET time_spent = time_spent + :seconds_spent
            WHERE id = :task_id
            AND user_id = :user_id";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':seconds_spent' => $secondsSpent,
        ':task_id' => $taskId,
        ':user_id' => $_SESSION['user_id']
    ]);

    return [
        'task' => getTaskById($taskId),
        'seconds_spent' => $secondsSpent
    ];
}