<?php

// In-memory task data
$tasks = [
    [
        "id" => 1,
        "name" => "Take out the trash",
        "status" => "Not Started",
        "dueDate" => "2023-10-10",
        "estimatedTime" => 60,
        "timeSpent" => 0,
        "description" => "Take out the trash to the curb for pickup.",
        "categoryId" => 1,
        "completedOn" => ""
    ],
    [
        "id" => 2,
        "name" => "Finish homework",
        "status" => "In Progress",
        "dueDate" => "2023-10-12",
        "estimatedTime" => 120,
        "timeSpent" => 30,
        "description" => "Complete math and science homework assignments.",
        "categoryId" => 2,
        "completedOn" => ""
    ],
    [
        "id" => 3,
        "name" => "Clean the kitchen",
        "status" => "Completed",
        "dueDate" => "2023-10-08",
        "estimatedTime" => 90,
        "timeSpent" => 90,
        "description" => "Wash dishes, wipe counters, and mop the floor.",
        "categoryId" => 1,
        "completedOn" => "2023-10-08"
    ]
];

// In-memory category data
$categories = [
    [
        "id" => 1,
        "name" => "cleaning",
        "color" => "#FF5733"
    ],
    [
        "id" => 2,
        "name" => "school",
        "color" => "#33C1FF"
    ]
];


// --------------------
// TASK FUNCTIONS
// --------------------

function getAllTasks() {
    global $tasks;
    return $tasks;
}

function getTaskById($id) {
    global $tasks;

    foreach ($tasks as $task) {
        if ($task["id"] == $id) {
            return $task;
        }
    }

    return null;
}

function createTask($data) {
    global $tasks;

    $newId = count($tasks) + 1;

    $newTask = [
        "id" => $newId,
        "name" => $data["name"],
        "status" => $data["status"],
        "dueDate" => $data["dueDate"],
        "estimatedTime" => $data["estimatedTime"],
        "timeSpent" => $data["timeSpent"] ?? 0,
        "description" => $data["description"] ?? "",
        "categoryId" => $data["categoryId"],
        "completedOn" => $data["completedOn"] ?? ""
    ];

    $tasks[] = $newTask;

    return $newTask;
}

function updateTask($id, $data) {
    global $tasks;

    foreach ($tasks as &$task) {
        if ($task["id"] == $id) {
            $task = array_merge($task, $data);
            $task["id"] = $id;
            return $task;
        }
    }

    return null;
}

function deleteTask($id) {
    global $tasks;

    foreach ($tasks as $index => $task) {
        if ($task["id"] == $id) {
            array_splice($tasks, $index, 1);
            return true;
        }
    }

    return false;
}


// --------------------
// CATEGORY FUNCTIONS
// --------------------

function getAllCategories() {
    global $categories;
    return $categories;
}

function getCategoryById($id) {
    global $categories;

    foreach ($categories as $category) {
        if ($category["id"] == $id) {
            return $category;
        }
    }

    return null;
}

function createCategory($data) {
    global $categories;

    $newId = count($categories) + 1;

    $newCategory = [
        "id" => $newId,
        "name" => $data["name"],
        "color" => $data["color"]
    ];

    $categories[] = $newCategory;

    return $newCategory;
}

function updateCategory($id, $data) {
    global $categories;

    foreach ($categories as &$category) {
        if ($category["id"] == $id) {
            $category = array_merge($category, $data);
            $category["id"] = $id;
            return $category;
        }
    }

    return null;
}

function deleteCategory($id) {
    global $categories;

    foreach ($categories as $index => $category) {
        if ($category["id"] == $id) {
            array_splice($categories, $index, 1);
            return true;
        }
    }

    return false;
}
?>