<?php

require_once __DIR__ . '/../../data/store.php';

header('Content-Type: application/json');

$id = $_GET['id'] ?? null;

if ($id === null) {
    http_response_code(400);
    echo json_encode([
        "error" => "Category ID is required"
    ]);
    exit;
}

$id = intval($id);

$deleted = deleteCategory($id);

if (!$deleted) {
    http_response_code(404);
    echo json_encode([
        "error" => "Category not found"
    ]);
    exit;
}

echo json_encode([
    "message" => "Category deleted successfully"
]);