<?php

require_once __DIR__ . '/../../data/store.php';
require_once __DIR__ . '/../../middleware/validate.php';

header('Content-Type: application/json');

$id = $_GET['id'] ?? null;

if ($id === null) {
    http_response_code(400);
    echo json_encode([
        "error" => "Category ID is required"
    ]);
    exit;
}

$id = intval($id);

$existingCategory = getCategoryById($id);

if (!$existingCategory) {
    http_response_code(404);
    echo json_encode([
        "error" => "Category not found"
    ]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

if ($data === null) {
    http_response_code(400);
    echo json_encode([
        "error" => "Invalid JSON"
    ]);
    exit;
}

// Merge existing category with the update data so partial updates can validate
$mergedData = array_merge($existingCategory, $data);

$errors = validateCategory($mergedData);

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode([
        "error" => "Validation failed",
        "fields" => $errors
    ]);
    exit;
}

$updatedCategory = updateCategory($id, $data);

echo json_encode($updatedCategory);