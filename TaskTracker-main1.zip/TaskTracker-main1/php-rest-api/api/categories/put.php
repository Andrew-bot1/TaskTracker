<?php

require_once __DIR__ . '/../../data/store.php';
require_once __DIR__ . '/../../middleware/validate.php';

header('Content-Type: application/json');

$id = $_GET['id'] ?? null;

if ($id === null) {
    http_response_code(400);
    echo json_encode([
        "error" => "Category ID is required"
    ]);
    exit;
}

$id = intval($id);

$data = json_decode(file_get_contents("php://input"), true);

if ($data === null) {
    http_response_code(400);
    echo json_encode([
        "error" => "Invalid JSON"
    ]);
    exit;
}

try {
    $existingCategory = getCategoryById($id);

    if (!$existingCategory) {
        http_response_code(404);
        echo json_encode([
            "error" => "Category not found"
        ]);
        exit;
    }

    // Merge existing category with update data so partial updates can validate
    $mergedData = array_merge($existingCategory, $data);

    $errors = validateCategory($mergedData);

    if (!empty($errors)) {
        http_response_code(400);
        echo json_encode([
            "error" => "Validation failed",
            "fields" => $errors
        ]);
        exit;
    }

    $updatedCategory = updateCategory($id, $data);

    if (!$updatedCategory) {
        http_response_code(500);
        echo json_encode([
            "error" => "Category update failed"
        ]);
        exit;
    }

    echo json_encode([
        "message" => "Category updated",
        "category" => $updatedCategory
    ]);
    exit;

} catch (PDOException $e) {
    error_log($e->getMessage());

    // MySQL constraint error, like duplicate value if you add UNIQUE later
    if ($e->getCode() === "23000") {
        http_response_code(409);
        echo json_encode([
            "error" => "A category with that value already exists"
        ]);
        exit;
    }

    http_response_code(500);
    echo json_encode([
        "error" => "Internal server error"
    ]);
    exit;
}