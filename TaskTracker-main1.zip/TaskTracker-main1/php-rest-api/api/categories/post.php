<?php

require_once __DIR__ . '/../../data/store.php';
require_once __DIR__ . '/../../middleware/validate.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

if ($data === null) {
    http_response_code(400);
    echo json_encode([
        "error" => "Invalid JSON"
    ]);
    exit;
}

if (isset($data["name"])) {
    $data["name"] = trim($data["name"]);
}

if (isset($data["color"])) {
    $data["color"] = trim($data["color"]);
}

$errors = validateCategory($data);

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode([
        "error" => "Validation failed",
        "fields" => $errors
    ]);
    exit;
}

try {
    $newCategory = createCategory($data);

    if (!$newCategory) {
        http_response_code(500);
        echo json_encode([
            "error" => "Category was not created"
        ]);
        exit;
    }

    http_response_code(201);
    echo json_encode([
        "message" => "Category created",
        "category" => $newCategory
    ]);
    exit;

} catch (PDOException $e) {
    error_log($e->getMessage());

    if ($e->getCode() === "23000") {
        http_response_code(409);
        echo json_encode([
            "error" => "A category with that value already exists"
        ]);
        exit;
    }

    http_response_code(500);
    echo json_encode([
        "error" => "Internal server error"
    ]);
    exit;
}