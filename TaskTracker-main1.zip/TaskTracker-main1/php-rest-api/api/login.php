<?php
session_start();

require_once __DIR__ . '/../db.php';

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../../login.html");
    exit;
}

$username = trim($_POST["username"] ?? "");
$password = $_POST["password"] ?? "";

if ($username === "" || $password === "") {
    http_response_code(400);
    echo "Username and password are required.";
    exit;
}

if (strlen($username) > 255) {
    http_response_code(400);
    echo "Username must be 255 characters or less.";
    exit;
}

try {
    $sql = "SELECT * FROM users WHERE username = :username";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ":username" => $username
    ]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo "Invalid username or password.";
        exit;
    }

    if (!password_verify($password, $user["password"])) {
        echo "Invalid username or password.";
        exit;
    }

    $_SESSION["user_id"] = $user["id"];
    $_SESSION["username"] = $user["username"];

    header("Location: ../../root/index.php");
    exit;

} catch (PDOException $e) {
    error_log($e->getMessage());

    http_response_code(500);
    echo "Internal server error.";
    exit;
}