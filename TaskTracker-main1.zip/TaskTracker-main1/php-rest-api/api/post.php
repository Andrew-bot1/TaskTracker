<?php

require_once __DIR__ . '/../data/store.php';
require_once __DIR__ . '/../middleware/validate.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

if ($data === null) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Invalid JSON"
    ]);
    exit;
}

// Trim string fields before validation/saving
if (isset($data["title"])) {
    $data["title"] = trim($data["title"]);
}

if (isset($data["description"])) {
    $data["description"] = trim($data["description"]);
}

if (isset($data["due_date"])) {
    $data["due_date"] = trim($data["due_date"]);
}

if (isset($data["completed_on"])) {
    $data["completed_on"] = trim($data["completed_on"]);
}

// Validate task data
$errors = validateTask($data);

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Validation failed",
        "fields" => $errors
    ]);
    exit;
}

try {
    $newTask = createTask($data);

    if (!$newTask) {
        http_response_code(500);
        echo json_encode([
            "status" => "error",
            "message" => "Task was not created"
        ]);
        exit;
    }

    http_response_code(201);
    echo json_encode([
        "status" => "success",
        "message" => "Task created",
        "task" => $newTask
    ]);
    exit;

} catch (PDOException $e) {
    error_log($e->getMessage());

    if ($e->getCode() === "23000") {
        http_response_code(400);
        echo json_encode([
            "status" => "error",
            "message" => "Invalid category, status, or user reference"
        ]);
        exit;
    }

    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Internal server error"
    ]);
    exit;
}