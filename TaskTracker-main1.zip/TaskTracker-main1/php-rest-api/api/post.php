<?php

require_once __DIR__ . '/../data/store.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

if ($data === null) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Invalid JSON"
    ]);
    exit;
}

if (empty($data["title"])) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Task title is required"
    ]);
    exit;
}

$newTask = createTask($data);

if (!$newTask) {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Task was not created"
    ]);
    exit;
}

echo json_encode([
    "status" => "success",
    "message" => "Task created",
    "task" => $newTask
]);
exit;