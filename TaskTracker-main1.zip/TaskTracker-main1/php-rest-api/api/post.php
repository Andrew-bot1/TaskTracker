<?php

require_once __DIR__ . '/../data/store.php';
require_once __DIR__ . '/../middleware/validate.php';

header('Content-Type: application/json');

// Read JSON body from Postman / frontend fetch
$data = json_decode(file_get_contents("php://input"), true);

if ($data === null) {
    http_response_code(400);
    echo json_encode([
        "error" => "Invalid JSON"
    ]);
    exit;
}

// Validate request body
$errors = validateTask($data);

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode([
        "error" => "Validation failed",
        "fields" => $errors
    ]);
    exit;
}

// Create task
$newTask = createTask($data);

http_response_code(201);
echo json_encode($newTask);