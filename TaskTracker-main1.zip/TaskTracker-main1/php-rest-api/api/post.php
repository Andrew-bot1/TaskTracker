<?php

require_once __DIR__ . '/../data/store.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

if ($data === null) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Invalid JSON"
    ]);
    exit;
}

if (empty($data["title"])) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Task title is required"
    ]);
    exit;
}

try {
    $newTask = createTask($data);

    if (!$newTask) {
        http_response_code(500);
        echo json_encode([
            "status" => "error",
            "message" => "Task was not created"
        ]);
        exit;
    }

    http_response_code(201);
    echo json_encode([
        "status" => "success",
        "message" => "Task created",
        "task" => $newTask
    ]);
    exit;

} catch (PDOException $e) {
    error_log($e->getMessage());

    // MySQL integrity constraint violation
    // This can happen if category_id, status_id, or user_id points to a record that does not exist.
    if ($e->getCode() === "23000") {
        http_response_code(400);
        echo json_encode([
            "status" => "error",
            "message" => "Invalid category, status, or user reference"
        ]);
        exit;
    }

    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Internal server error"
    ]);
    exit;
}