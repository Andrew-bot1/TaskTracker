<?php

require_once __DIR__ . '/../data/store.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

if ($data === null) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Invalid JSON"
    ]);
    exit;
}

$taskId = $data["task_id"] ?? null;
$action = $data["action"] ?? null;

if (!$taskId || !$action) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Task ID and action are required"
    ]);
    exit;
}

if ($action === "start") {
    $log = startTaskTimer($taskId);

    if (!$log) {
        http_response_code(404);
        echo json_encode([
            "status" => "error",
            "message" => "Task not found"
        ]);
        exit;
    }

    echo json_encode([
        "status" => "success",
        "message" => "Timer started",
        "log" => $log
    ]);
    exit;
}

if ($action === "stop") {
    $result = stopTaskTimer($taskId);

    if (!$result) {
        http_response_code(400);
        echo json_encode([
            "status" => "error",
            "message" => "No active timer found"
        ]);
        exit;
    }

    echo json_encode([
        "status" => "success",
        "message" => "Timer stopped",
        "seconds_spent" => $result["seconds_spent"],
        "task" => $result["task"]
    ]);
    exit;
}

http_response_code(400);
echo json_encode([
    "status" => "error",
    "message" => "Invalid timer action"
]);
exit;