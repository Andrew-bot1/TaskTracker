<?php

require_once __DIR__ . '/../data/store.php';
require_once __DIR__ . '/../middleware/validate.php';

header('Content-Type: application/json');

$id = $_GET['id'] ?? null;

if ($id === null) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Task ID is required"
    ]);
    exit;
}

$id = intval($id);

$data = json_decode(file_get_contents("php://input"), true);

if ($data === null) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Invalid JSON"
    ]);
    exit;
}

try {
    $existingTask = getTaskById($id);

    if (!$existingTask) {
        http_response_code(404);
        echo json_encode([
            "status" => "error",
            "message" => "Task not found"
        ]);
        exit;
    }

    // Merge old task data with new data so partial updates can validate correctly
    $mergedData = array_merge($existingTask, $data);

    $errors = validateTask($mergedData);

    if (!empty($errors)) {
        http_response_code(400);
        echo json_encode([
            "status" => "error",
            "message" => "Validation failed",
            "fields" => $errors
        ]);
        exit;
    }

    // Trim string fields before saving
    if (isset($data["title"])) {
        $data["title"] = trim($data["title"]);
    }

    if (isset($data["description"])) {
        $data["description"] = trim($data["description"]);
    }

    if (isset($data["due_date"])) {
        $data["due_date"] = trim($data["due_date"]);
    }

    if (isset($data["completed_on"])) {
        $data["completed_on"] = trim($data["completed_on"]);
    }

    $updatedTask = updateTask($id, $data);

    if (!$updatedTask) {
        http_response_code(500);
        echo json_encode([
            "status" => "error",
            "message" => "Task update failed"
        ]);
        exit;
    }

    echo json_encode([
        "status" => "success",
        "message" => "Task updated",
        "task" => $updatedTask
    ]);
    exit;

} catch (PDOException $e) {
    error_log($e->getMessage());

    if ($e->getCode() === "23000") {
        http_response_code(400);
        echo json_encode([
            "status" => "error",
            "message" => "Invalid category, status, or user reference"
        ]);
        exit;
    }

    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Internal server error"
    ]);
    exit;
}