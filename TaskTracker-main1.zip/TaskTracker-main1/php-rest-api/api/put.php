<?php

require_once __DIR__ . '/../data/store.php';

header('Content-Type: application/json');

$id = $_GET['id'] ?? null;

if ($id === null) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Task ID is required"
    ]);
    exit;
}

$id = intval($id);

$data = json_decode(file_get_contents("php://input"), true);

if ($data === null) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Invalid JSON"
    ]);
    exit;
}

$existingTask = getTaskById($id);

if (!$existingTask) {
    http_response_code(404);
    echo json_encode([
        "status" => "error",
        "message" => "Task not found"
    ]);
    exit;
}

$updatedTask = updateTask($id, $data);

if (!$updatedTask) {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Task update failed"
    ]);
    exit;
}

echo json_encode([
    "status" => "success",
    "message" => "Task updated",
    "task" => $updatedTask
]);
exit;