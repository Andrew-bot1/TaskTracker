<?php

require_once __DIR__ . '/../data/store.php';

header('Content-Type: application/json');

$id = $_GET['id'] ?? null;

if ($id !== null) {
    $task = getTaskById(intval($id));

    if (!$task) {
        http_response_code(404);
        echo json_encode([
            "error" => "Task not found"
        ]);
        exit;
    }

    echo json_encode($task);
    exit;
}

echo json_encode([
    "tasks" => getAllTasks(),
    "categories" => getAllCategories()
]);