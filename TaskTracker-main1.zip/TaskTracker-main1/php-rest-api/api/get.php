<?php

header("Content-Type: application/json");

$resource = $_GET["resource"] ?? "tasks";
$id = $_GET["id"] ?? null;

if ($resource === "tasks") {
    if ($id) {
        echo json_encode([
            "task" => getTaskById($id)
        ]);
    } else {
        echo json_encode([
            "tasks" => getAllTasks()
        ]);
    }
    exit;
}

if ($resource === "categories") {
    if ($id) {
        echo json_encode([
            "category" => getCategoryById($id)
        ]);
    } else {
        echo json_encode([
            "categories" => getAllCategories()
        ]);
    }
    exit;
}

if ($resource === "completed") {
    echo json_encode([
        "tasks" => getCompletedTasks()
    ]);
    exit;
}

http_response_code(404);
echo json_encode([
    "error" => "Resource not found",
    "resource" => $resource
]);
exit;