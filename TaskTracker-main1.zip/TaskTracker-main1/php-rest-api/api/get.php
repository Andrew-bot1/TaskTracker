<?php

header("Content-Type: application/json");

$resource = trim($_GET["resource"] ?? "tasks");
$id = $_GET["id"] ?? null;

if ($id !== null && !is_numeric($id)) {
    http_response_code(400);
    echo json_encode([
        "error" => "ID must be a number"
    ]);
    exit;
}

try {
    if ($resource === "tasks") {
        if ($id !== null) {
            $task = getTaskById((int)$id);

            if (!$task) {
                http_response_code(404);
                echo json_encode([
                    "error" => "Task not found"
                ]);
                exit;
            }

            echo json_encode([
                "task" => $task
            ]);
            exit;
        }

        echo json_encode([
            "tasks" => getAllTasks()
        ]);
        exit;
    }

    if ($resource === "categories") {
        if ($id !== null) {
            $category = getCategoryById((int)$id);

            if (!$category) {
                http_response_code(404);
                echo json_encode([
                    "error" => "Category not found"
                ]);
                exit;
            }

            echo json_encode([
                "category" => $category
            ]);
            exit;
        }

        echo json_encode([
            "categories" => getAllCategories()
        ]);
        exit;
    }

    if ($resource === "completed") {
        echo json_encode([
            "tasks" => getCompletedTasks()
        ]);
        exit;
    }

    http_response_code(404);
    echo json_encode([
        "error" => "Resource not found",
        "resource" => $resource
    ]);
    exit;

} catch (PDOException $e) {
    error_log($e->getMessage());

    http_response_code(500);
    echo json_encode([
        "error" => "Internal server error"
    ]);
    exit;
}