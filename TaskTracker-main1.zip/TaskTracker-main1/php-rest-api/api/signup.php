<?php
session_start();

require_once __DIR__ . '/../db.php';

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../../signup.php");
    exit;
}

$username = trim($_POST["username"] ?? "");
$password = $_POST["password"] ?? "";
$confirmPassword = $_POST["confirmPassword"] ?? "";

if ($username === "" || $password === "" || $confirmPassword === "") {
    http_response_code(400);
    echo "All fields are required.";
    exit;
}

if ($password !== $confirmPassword) {
    http_response_code(400);
    echo "Passwords do not match.";
    exit;
}

try {
    $sql = "SELECT id FROM users WHERE username = :username";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ":username" => $username
    ]);

    $existingUser = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existingUser) {
        http_response_code(409);
        echo "That username is already taken.";
        exit;
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (username, password) VALUES (:username, :password)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ":username" => $username,
        ":password" => $hashedPassword
    ]);

    $_SESSION["user_id"] = $pdo->lastInsertId();
    $_SESSION["username"] = $username;

    header("Location: ../../root/index.php");
    exit;

} catch (PDOException $e) {
    error_log($e->getMessage());

    // MySQL integrity constraint violation, like duplicate username
    if ($e->getCode() === "23000") {
        http_response_code(409);
        echo "That username is already taken.";
        exit;
    }

    http_response_code(500);
    echo "Internal server error.";
    exit;
}