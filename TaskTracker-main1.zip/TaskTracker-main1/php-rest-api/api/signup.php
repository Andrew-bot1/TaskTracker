<?php
session_start();

require_once __DIR__ . '/../db.php';

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../../signup.php");
    exit;
}

$username = trim($_POST["username"] ?? "");
$password = $_POST["password"] ?? "";
$confirmPassword = $_POST["confirmPassword"] ?? "";

if ($username === "" || $password === "" || $confirmPassword === "") {
    echo "All fields are required.";
    exit;
}

if ($password !== $confirmPassword) {
    echo "Passwords do not match.";
    exit;
}

$sql = "SELECT id FROM users WHERE username = :username";
$stmt = $pdo->prepare($sql);
$stmt->execute([
    ":username" => $username
]);

$existingUser = $stmt->fetch(PDO::FETCH_ASSOC);

if ($existingUser) {
    echo "That username is already taken.";
    exit;
}

$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

$sql = "INSERT INTO users (username, password) VALUES (:username, :password)";
$stmt = $pdo->prepare($sql);
$stmt->execute([
    ":username" => $username,
    ":password" => $hashedPassword
]);

$_SESSION["user_id"] = $pdo->lastInsertId();
$_SESSION["username"] = $username;

header("Location: ../../index.php");
exit;