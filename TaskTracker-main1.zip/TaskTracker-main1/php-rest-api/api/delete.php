<?php

require_once __DIR__ . '/../data/store.php';

header('Content-Type: application/json');

$id = $_GET['id'] ?? null;

if ($id === null) {
    http_response_code(400);
    echo json_encode([
        "error" => "Task ID is required"
    ]);
    exit;
}

if (!is_numeric($id)) {
    http_response_code(400);
    echo json_encode([
        "error" => "Task ID must be a number"
    ]);
    exit;
}

$id = intval($id);

try {
    $deleted = deleteTask($id);

    if (!$deleted) {
        http_response_code(404);
        echo json_encode([
            "error" => "Task not found"
        ]);
        exit;
    }

    echo json_encode([
        "message" => "Task deleted successfully"
    ]);
    exit;

} catch (PDOException $e) {
    error_log($e->getMessage());

    http_response_code(500);
    echo json_encode([
        "error" => "Internal server error"
    ]);
    exit;
}