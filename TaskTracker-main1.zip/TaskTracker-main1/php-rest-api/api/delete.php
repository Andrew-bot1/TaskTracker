<?php

require_once __DIR__ . '/../data/store.php';

header('Content-Type: application/json');

$id = $_GET['id'] ?? null;

if ($id === null) {
    http_response_code(400);
    echo json_encode([
        "error" => "Task ID is required"
    ]);
    exit;
}

$id = intval($id);

$deleted = deleteTask($id);

if (!$deleted) {
    http_response_code(404);
    echo json_encode([
        "error" => "Task not found"
    ]);
    exit;
}

echo json_encode([
    "message" => "Task deleted successfully"
]);