INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'john_doe', '$2y$10$92IXUNpkj0rOuWflGSLTPeJ0QV4V8sK289MzMJB6gKXVC4oU9jPXu'),
(2, 'jane_smith', '$2y$10$92IXUNpkj0rOuWflGSLTPeJ0QV4V8sK289MzMJB6gKXVC4oU9jPXu'),
(3, 'alice_wonder', '$2y$10$92IXUNpkj0rOuWflGSLTPeJ0QV4V8sK289MzMJB6gKXVC4oU9jPXu');

INSERT INTO `categories` (`id`, `user_id`, `name`, `color`) VALUES
(1, 1, 'Work', '#FF5733'),
(2, 1, 'Personal', '#33FF57'),
(3, 1, 'Hobby', '#3357FF'),
(4, 2, 'School', '#FF00FF'),
(5, 2, 'Chores', '#00FFFF'),
(6, 3, 'Fitness', '#FFFF00');

INSERT INTO `statuses` (`id`, `name`) VALUES
(1, 'To Do'),
(2, 'In Progress'),
(3, 'Done');

INSERT INTO `tasks` 
(`id`, `user_id`, `title`, `description`, `due_date`, `time_spent`, `estimated_time`, `completed_on`, `category_id`, `status_id`) 
VALUES
(1, 1, 'Finish project report', 'Complete the final report for the project', '2026-05-12', 120, 180, NULL, 1, 2),
(2, 1, 'Buy groceries', 'Milk, Bread, Eggs, and Fruits', '2026-05-09', 30, 60, NULL, 2, 1),
(3, 2, 'Plan weekend trip', 'Research and plan activities for the weekend trip', '2026-05-15', 60, 120, NULL, 3, 1),
(4, 3, 'Practice guitar', 'Spend time practicing guitar chords and songs', '2026-05-10', 45, 90, NULL, 3, 2),
(5, 3, 'Read a book', 'Read the new novel by the favorite author', '2026-05-18', 20, 60, NULL, 2, 1),
(6, 2, 'Prepare presentation', 'Create slides and practice for the upcoming presentation', '2026-05-13', 90, 150, NULL, 1, 2),
(7, 1, 'Organize workspace', 'Clean and organize the home office space', '2026-05-11', 15, 30, NULL, 2, 1),
(8, 2, 'Exercise', 'Go for a run and do some strength training', '2026-05-09', 60, 90, NULL, 2, 2),
(9, 3, 'Cook dinner', 'Try a new recipe for dinner', '2026-05-09', 45, 60, NULL, 2, 1),
(10, 1, 'Update resume', 'Add recent work experience and skills to the resume', '2026-05-16', 30, 60, NULL, 1, 1);

INSERT INTO `time_logs` (`id`, `task_id`, `start_time`, `end_time`) VALUES
(1, 1, '2024-06-25 09:00:00', '2024-06-25 11:00:00'),
(2, 1, '2024-06-26 14:00:00', '2024-06-26 16:00:00'),
(3, 2, '2024-06-29 17:00:00', '2024-06-29 17:30:00'),
(4, 3, '2024-07-01 10:00:00', '2024-07-01 11:00:00'),
(5, 4, '2024-07-01 18:00:00', '2024-07-01 18:45:00');